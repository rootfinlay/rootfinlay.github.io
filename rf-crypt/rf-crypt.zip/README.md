# rf-crypt
 rf crypt - encryption algorithm you can trust

 PLEASE NOTE:  rf-crypt in its current stage is an experiment and should NOT be used to replace other encryption algorithms, but who am I to tell you what to do.

# rf-crypt.py
 rf-crypt.py is the main bridge for all the rf-crypt segments.  You have ultimate control of everything.
 Usage:
 ```console
 # Run the script

 $ python3 rf-crypt.py

 # Enter your desired option.
 
  ██▀███    █████▒▄████▄   ██▀███ ▓██   ██▓ ██▓███  ▄▄▄█████▓
 ▓██ ▒ ██▒▓██   ▒▒██▀ ▀█  ▓██ ▒ ██▒▒██  ██▒▓██░  ██▒▓  ██▒ ▓▒
 ▓██ ░▄█ ▒▒████ ░▒▓█    ▄ ▓██ ░▄█ ▒ ▒██ ██░▓██░ ██▓▒▒ ▓██░ ▒░
 ▒██▀▀█▄  ░▓█▒  ░▒▓▓▄ ▄██▒▒██▀▀█▄   ░ ▐██▓░▒██▄█▓▒ ▒░ ▓██▓ ░ 
 ░██▓ ▒██▒░▒█░   ▒ ▓███▀ ░░██▓ ▒██▒ ░ ██▒▓░▒██▒ ░  ░  ▒██▒ ░ 
 ░ ▒▓ ░▒▓░ ▒ ░   ░ ░▒ ▒  ░░ ▒▓ ░▒▓░  ██▒▒▒ ▒▓▒░ ░  ░  ▒ ░░
  ░▒ ░ ▒░ ░       ░  ▒     ░▒ ░ ▒░▓██ ░▒░ ░▒ ░         ░
  ░░   ░  ░ ░   ░          ░░   ░ ▒ ▒ ░░  ░░         ░
   ░            ░ ░         ░     ░ ░
                ░                 ░ ░

                               v0.1.0

 Would you like to: (NOTE SOME OPTIONS ARE A WORK IN PROGRESS)
 1)  Generate new keypair
 2)  Import rf-crypt key
 3)  Sign message
 4)  Check message signature
 5)  Encrypt message
 6)  Decrypt message
 7)  About
 8)  Exit

 >

 # Then the program will run based on your option.
```
# rf-crypt

rf-crypt (rfc) is an assymetric and (soon to be) asymmetric encryption algorithm using maths.  Strength relative to other algorithms isn't currently measured.
rf-crypt uses maths and a bit modulus to make crypting strings with a password rather unique

# rf-hash

rf-hash (rfh) is a hashing algorithm with 256-2048bit support (with a 3301bit option as an easteregg ;)
rfh uses math and xor to create a one way string which cannot be reversed at all

rfh can be used through the rf-crypt client or through rfh.py

# rf-keygen

rf-keygen (rfk) is a keygen algorithm using rfh which will be used in the soon to arrive assymetric encryption of rfc.
Please be aware that rfk is subject to change at any time.


# The Challenge

Marking the completion of the hashing algorithm and symmetric key encryption of rf-crypt, a challenge has been devised.  Those who can crack either will have the bragging rights.
