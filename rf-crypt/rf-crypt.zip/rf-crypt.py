import rfh
import rfk
import rfc
import time

def about():
    print("\n\nrf-crypt is an encryption suite which includes a hashing algorithm,\n"
          "public and private key generator and public and private key encryption.\n"
          "\n"
          "rf-hash (rfh) is a hashing algortihm written in python which uses maths,\n"
          "xor and the fact that the original number in a mathematical operation\n"
          "would need to be known in order to calcualte the original value.  Currently\n"
          "rfh is available in 256-2048bits with the potential addition of 4096bit\n"
          "hashes if needed.\n"
          "\n"
          "rf-keygen (rfk) is a public and private key generator using rfh.  Currently,\n"
          "rfk is in the early stages with ideas constantly being toyed with.  For now,\n"
          "ECDSA is recommended, but beware of the security flaws.\n"
          "\n"
          "rf-crypt (rfc) is both an asymmetric and symmetric encryption system which\n"
          "uses rfh and rfk.  Currently, rfc is in a very early state and should not\n"
          "be used, unless for testing.  When completed, rfc will be used in other rf\n"
          "projects such as Devote and Silence.\n"
          "\n"
          "the rf team:\n"
          "rootfinlay - lead developer & founder\n"
          "CryptCoder - lead developer\n"
          )

def easteregg():
    print(
        "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
        " ██▀███    █████▒▄████▄   ██▀███ ▓██   ██▓ ██▓███  ▄▄▄█████▓\n"
        "▓██ ▒ ██▒▓██   ▒▒██▀ ▀█  ▓██ ▒ ██▒▒██  ██▒▓██░  ██▒▓  ██▒ ▓▒\n"
        "▓██ ░▄█ ▒▒████ ░▒▓█    ▄ ▓██ ░▄█ ▒ ▒██ ██░▓██░ ██▓▒▒ ▓██░ ▒░\n"
        "▒██▀▀█▄  ░▓█▒  ░▒▓▓▄ ▄██▒▒██▀▀█▄   ░ ▐██▓░▒██▄█▓▒ ▒░ ▓██▓ ░ \n"
        "░██▓ ▒██▒░▒█░   ▒ ▓███▀ ░░██▓ ▒██▒ ░ ██▒▓░▒██▒ ░  ░  ▒██▒ ░ \n"
        "░ ▒▓ ░▒▓░ ▒ ░   ░ ░▒ ▒  ░░ ▒▓ ░▒▓░  ██▒▒▒ ▒▓▒░ ░  ░  ▒ ░░   \n"
        "  ░▒ ░ ▒░ ░       ░  ▒     ░▒ ░ ▒░▓██ ░▒░ ░▒ ░         ░    \n"
        "  ░░   ░  ░ ░   ░          ░░   ░ ▒ ▒ ░░  ░░         ░      \n"
        "   ░            ░ ░         ░     ░ ░                       \n"
        "                ░                 ░ ░                       \n"
        "\n"
        "                              v0.1.0                          \n"
        "\n"
        "\n"
        "\n"
        "                       Presented by: rootfinlay\n"
    )
    time.sleep(1)
    print(
        "root@datacenter-08ace8d94:~# cat /var/log/deac/deac.log"
    )
    time.sleep(0.5)
    print(
        "[01:23] - Login from unkn0wn IP:  19.64.243.13 with account:  www-data\n"
        "[01:24] - Potentially malicious user executed command: www-data@datacenter-08ace8d94:~$ sudo -l\n"
        "[01:24] - User www-data failed to provide signed message with key 0xRFCRYPT07\n"
        "[01:24] - Services migrated..\n"
        "[01:25] - User www-data locked awaiting sanitisation...\n"
        "[10:33] - User www-data sanitised by account: root\n\n"

        "[DEAC] - EndLog code 101\n"
    )
    time.sleep(1.5)
    print(
        "root@datacenter-08ace8d94:~# python /home/rf/rf-crypt/deac.py --status\n"
        "----- rf-crypt deac v0.1.0 -----\n"
        "STATUS:    Connected\n"
        "UPTIME:    3days\n"
        "USERS:     3\n"
        "ISSUES:    0\n"
        "RESOLVED:  1\n"
    )
    time.sleep(1.5)
    print(
        "root@datacenter-08ace8d94:~# exit"
        )
    pass

def GenKeypair():
    name = input("Please input your name:\n> ")
    password = input("Please input a password:\n> ")
    rfk.GenKeypair(name, password)
    print("\n\n\n\n")
    main()

def ImportKey():
    file = input("Please input the name of the public/privatekey file you want to import:\n> ")
    with open(file, "r") as f:
        firstline = f.readline()
        if 'PRIVKEY' in firstline:
            filetype = "private"
            f.close()
            password = input("Please input the password used to encrypt the private key:\n> ")
            rfk.ImportPrivateKey(file, password)
        elif 'PUBKEY' in firstline:
            filetype = "public"
            f.close()
            rfk.ImportPublicKey(file)
    main()

def EncryptMessage():
    enctype = input("Would you like to use (s)ymmetric or (a)symmetric encryption?\n> ")
    if enctype == "s":
        plaintext = input("Please input the text you wish to encrypt:\n> ")
        password = input("Please enter the password you wish to use:\n> ")
        modulus = input("Please input the modulus: (default=29)\n> ")
        if modulus == "":
            modulus = 29
        result = rfc.EncryptMessageSymmetrical(plaintext, password, int(modulus))
        print("Ciphertext: " + result)
    elif enctype == "a":
        print("Not available yet")
        time.sleep(3)
        main()
    else:
        print("Invalid Option")
        main()

def DecryptMessage():
    dectype = input("Would you like to use (a)symmetric or (s)ymmetric decryption?\n> ")
    if dectype == "s":
        ciphertext = input("Please input the ciphertext you wish to decrypt:\n> ")
        password = input("Please enter the password you wish to use:\n> ")
        modulus = input("Please input the modulus: (default=29)\n> ")
        if modulus == "":
            modulus = 29
        result = rfc.DecryptMessageSymmetrical(ciphertext, password, int(modulus))
        print("Plaintext: " + result)
    elif dectype == "a":
        print("Not available yet")
        time.sleep(3)
        main()
    else:
        print("Invalid Option")
        main()

def HashMessage():
    strtohash = input("Please input the string you would like to hash:\n> ")
    bits = input("What bit selection would you like?  Options: 256, 512, 1024, 2048\n> ")
    if bits == "256":
        res = rfh.rfh256(str(strtohash))
    elif bits == "512":
        res = rfh.rfh512(str(strtohash))
    elif bits == "1024":
        res = rfh.rfh1024(str(strtohash))
    elif bits == "2048":
        res = rfh.rfh2048(str(strtohash))
    elif bits == "3301":
        res = rfh.rfh3301(str(strtohash))

    print("Hash:  " + res)


def main():
    print(
        "\n\n\n"
        " ██▀███    █████▒▄████▄   ██▀███ ▓██   ██▓ ██▓███  ▄▄▄█████▓\n"
        "▓██ ▒ ██▒▓██   ▒▒██▀ ▀█  ▓██ ▒ ██▒▒██  ██▒▓██░  ██▒▓  ██▒ ▓▒\n"
        "▓██ ░▄█ ▒▒████ ░▒▓█    ▄ ▓██ ░▄█ ▒ ▒██ ██░▓██░ ██▓▒▒ ▓██░ ▒░\n"
        "▒██▀▀█▄  ░▓█▒  ░▒▓▓▄ ▄██▒▒██▀▀█▄   ░ ▐██▓░▒██▄█▓▒ ▒░ ▓██▓ ░ \n"
        "░██▓ ▒██▒░▒█░   ▒ ▓███▀ ░░██▓ ▒██▒ ░ ██▒▓░▒██▒ ░  ░  ▒██▒ ░ \n"
        "░ ▒▓ ░▒▓░ ▒ ░   ░ ░▒ ▒  ░░ ▒▓ ░▒▓░  ██▒▒▒ ▒▓▒░ ░  ░  ▒ ░░   \n"
        "  ░▒ ░ ▒░ ░       ░  ▒     ░▒ ░ ▒░▓██ ░▒░ ░▒ ░         ░    \n"
        "  ░░   ░  ░ ░   ░          ░░   ░ ▒ ▒ ░░  ░░         ░      \n"
        "   ░            ░ ░         ░     ░ ░                       \n"
        "                ░                 ░ ░                       \n"
        "\n"
        "                              v0.1.0                          \n"
    )
    print("Would you like to:")
    print("1)  Generate new keypair")
    print("2)  Import rf-crypt key")
    print("3)  Sign message")
    print("4)  Check message signature")
    print("5)  Encrypt message")
    print("6)  Decrypt message")
    print("7)  Hash a string")
    print("8)  About")
    print("9)  Exit")

    mainchoice = input("\n> ")

    if mainchoice == "1":
        GenKeypair()
    elif mainchoice == "2":
        ImportKey()
    elif mainchoice == "3":
        SignMessage()
    elif mainchoice == "4":
        CheckSignature()
    elif mainchoice == "5":
        EncryptMessage()
    elif mainchoice == "6":
        DecryptMessage()
    elif mainchoice == "7":
        HashMessage()
    elif mainchoice == "8":
        about()
    elif mainchoice == "9":
        pass
    elif mainchoice == "easteregg":
        easteregg()
    else:
        print("Error..")

if __name__ == "__main__":
    main()