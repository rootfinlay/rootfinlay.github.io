import rfh
import base64

StringToNumbers = {
   "a" : 1931,
   "b" : 2381,
   "c" : 3301,
   "d" : 6091,
   "e" : 7817,
   "f" : 7103,
   "g" : 457,
   "h" : 2207,
   "i" : 2729,
   "j" : 743,
   "k" : 107,
   "l" : 1229,
   "m" : 29,
   "n" : 4007,
   "o" : 1193,
   "p" : 673,
   "q" : 71,
   "r" : 3889,
   "s" : 1613, 
   "t" : 1721,
   "u" : 1447,
   "v" : 3571,
   "w" : 547,
   "x" : 157,
   "y" : 3203,
   "z" : 2311,
   "A" : 7919,
   "B" : 4759,
   "C" : 3251,
   "D" : 6679,
   "E" : 811,
   "F" : 1783,
   "G" : 11,
   "H" : 631,
   "I" : 4007,
   "J" : 6689,
   "K" : 7829,
   "L" : 2243,
   "M" : 701,
   "N" : 1061,
   "O" : 283,
   "P" : 401,
   "Q" : 607,
   "R" : 113,
   "S" : 5023,
   "T" : 3581, 
   "U" : 7121,
   "V" : 7129,
   "W" : 5009,
   "X" : 6421,
   "Y" : 3253,
   "Z" : 947,
   "1" : 2069,
   "2" : 1409,
   "3" : 3557,
   "4" : 2347,
   "5" : 5113,
   "6" : 4909,
   "7" : 809,
   "8" : 2017,
   "9" : 193,
   "0" : 1033,
   " " : 2689,
   "!" : 1451,
   "£" : 1123,
   '"' : 317,
   "$" : 613,
   "%" : 1069,
   "^" : 7649,
   "&" : 5281,
   "*" : 2551,
   "(" : 4903,
   ")" : 5519,
   "-" : 4111,
   "_" : 4211,
   "=" : 1877,
   "+" : 5,
   "[" : 4229,
   "]" : 6701,
   ":" : 7717,
   ";" : 4019,
   "'" : 6329,
   "@" : 5879,
   "#" : 2137,
   "~" : 641,
   "," : 5843,
   "<" : 5381,
   "." : 2351,
   "/" : 7727,
   "?" : 7879,
   "`" : 61,
   "¬" : 997,
   "" : 2789,
}

NumbersToLetters = {
   1931: 'a',
   2381: 'b',
   3301: 'c',
   6091: 'd',
   7817: 'e', 
   7103: 'f', 
   457: 'g', 
   2207: 'h', 
   2729: 'i', 
   743: 'j', 
   107: 'k', 
   1229: 'l', 
   29: 'm', 
   4007: 'n', 
   1193: 'o', 
   673: 'p', 
   71: 'q', 
   3889: 'r', 
   1613: 's', 
   1721: 't', 
   1447: 'u', 
   3571: 'v', 
   547: 'w', 
   157: 'x', 
   3203: 'y', 
   2311: 'z', 
   7919: 'A', 
   4759: 'B', 
   3251: 'C', 
   6679: 'D', 
   811: 'E', 
   1783: 'F', 
   11: 'G', 
   631: 'H', 
   6689: 'J', 
   7829: 'K', 
   2243: 'L', 
   701: 'M', 
   1061: 'N', 
   283: 'O', 
   401: 'P', 
   607: 'Q', 
   113: 'R', 
   5023: 'S', 
   3581: 'T', 
   7121: 'U', 
   7129: 'V', 
   5009: 'W', 
   6421: 'X', 
   3253: 'Y', 
   947: 'Z', 
   2069: '1', 
   1409: '2', 
   3557: '3', 
   2347: '4', 
   5113: '5', 
   4909: '6', 
   809: '7', 
   2017: '8', 
   193: '9', 
   1033: '0', 
   2689: ' ', 
   1451: '!', 
   1123: '£', 
   317: '"', 
   613: '$', 
   1069: '%', 
   7649: '^', 
   5281: '&', 
   2551: '*', 
   4903: '(', 
   5519: ')', 
   4111: '-', 
   4211: '_', 
   1877: '=', 
   5: '+', 
   4229: '[', 
   6701: ']', 
   7717: ':', 
   4019: ';', 
   6329: "'", 
   5879: '@', 
   2137: '#', 
   641: '~', 
   5843: ',', 
   5381: '<', 
   2351: '.', 
   7727: '/', 
   7879: '?', 
   61: '`', 
   997: '¬',
   2789: '',
}

def EncryptMessageSymmetrical(plaintext, password, modulus):
   out = ''
   pos = 3301
   pos2 = 5
   secret = (rfh.XORFunction(len(plaintext), len(password))*modulus)
   for letter in plaintext:
      total = StringToNumbers[letter]
      for letterz in password:
         total += int(StringToNumbers[letterz]*int(pos+int(modulus+(int(modulus)%pos2)+secret)))
         pos+=761
         pos2+=1

      out+= ' ' + str(total)

   encodedBytes = base64.b64encode(out.encode("utf-8"))
   base64out = str(encodedBytes, "utf-8")

   return base64out

def DecryptMessageSymmetrical(ciphertext, password, modulus):
   encodedBytes = base64.b64decode(ciphertext.encode("utf-8"))
   ciphertext1 = str(encodedBytes, "utf-8")

   ciphertext = list(map(int,ciphertext1.strip().split()))
   
   out = ''
   pos = 3301
   pos2 = 5
   secret = (rfh.XORFunction(len(ciphertext), len(password))*modulus)
   for res in ciphertext:
      for letter in password:
         res = int(res)-(StringToNumbers[letter]*(pos+int(modulus+(modulus%pos2)+secret)))
         pos+=761
         pos2+=1
      try:
         out+=NumbersToLetters[res]
      except:
         return "Cannot decrypt message, please check the ciphertext, password and modulo then try again."

   return out

if __name__ == '__main__':
   messagetype = input("Would you like to (e)ncrypt or (d)ecrypt:\n> ")
   if messagetype == "e":
      plaintext = input("Please input the plaintext message:\n> ")
      password = input("Please input the password:\n> ")
      modulus = input("Please input the modulus (default=29):\n> ")
      if modulus == "":
         modulus = 29
      outmessage = EncryptMessageSymmetrical(plaintext, password, modulus)
   elif messagetype == "d":
      #ciphertext = input("Please input the ciphertext:\n> ")
      try:
         ciphertext = list(map(int,input("\nEnter the Ciphertext:\n> ").strip().split()))
      except:
         print("Ciphertext should only contain numbers.. try again.")
         pass
      password = input("Please input the password:\n> ")
      modulus = input("Please input the modulus:\n> ")
      outmessage = DecryptMessageSymmetrical(ciphertext, password, modulus)
   else:
      print("Invalid Option")

   print(outmessage)