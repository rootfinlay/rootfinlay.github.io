import rfh
import rfc
import string, base64, json, random

def GenKeypair(name, password):
    alphabet = string.ascii_letters + string.digits
    seedphrase = ''.join(random.choice(alphabet) for i in range(0,4096))
    seedphrase += password
    seedphrasehash = rfh.rfh2048(seedphrase)
    passwordhash = rfh.rfh2048(password)
    n = len(seedphrasehash)
    if n%2 == 0:
        privatekeyhalf = seedphrasehash[0:n//2]
        publickeyhalf = seedphrasehash[n//2:]
    else:
        privatekeyhalf = seedphrasehash[0:(n//2+1)]
        publickeyhalf = seedphrasehash[(n//2+1):]
    
    publickey = int(publickeyhalf, 16)
    privatekey = int(privatekeyhalf, 16)
    privatekeyencrypted = rfc.EncryptMessageSymmetrical(str(privatekey), password, modulus=33011033)

    link = publickey + privatekey

    public_fingerprint = GetFingerprint(publickey)
    private_fingerprint = GetFingerprint(privatekey)

    kr_block = {
        "pubkey" : publickey,
        "privkey" : privatekeyencrypted,
        "name:" : name,
        "password" : passwordhash,
        "link" : link,
        "public_fingerprint" : public_fingerprint,
        "private_fingerprint" : private_fingerprint,
    }

    krjson = json.dumps(kr_block)

    with open('keys/personalkeyring.kr', "a+") as k:
        k.write(krjson + "\n")
        k.close()

    encoded_pub = EncodePublicKey(publickey, name)
    encoded_priv = EncodePrivateKey(privatekeyencrypted, name, link)

    pubfile = name
    pubfile += ".pub"
    privfile = name
    privfile += ".priv"

    with open("keys/"+pubfile, "w+") as pubf:
        pubf.write(encoded_pub)
        pubf.close()

    with open("keys/"+privfile, "w+") as privf:
        privf.write(encoded_priv)
        privf.close()

def EncodePublicKey(publickey, name):
    out = ''.join("               ----- BEGIN RF PUBKEY BLOCK -----\n\n\n")
    out += "Name:  " + name + "\n\n"
    count = 0
    for character in str(publickey):
        count += 1
        if count == 64:
            out += "\n"
            count = 0
        else:
            out += character
    out += "\n               ----- END RF PUBKEY BLOCK -----"
    return out

def EncodePrivateKey(privatekeyencrypted, name, link):
    out = ''.join("              ----- BEGIN ENCRYPTED RF PRIVKEY BLOCK -----\n\n\n")
    out += "Name:  " + name + "\n"
    out += "Link:  " + str(link) + "\n\n"
    count = 0
    for character in str(privatekeyencrypted):
        count += 1
        out += character
    out += "\n              ----- END ENCRYPTED RF PRIVKEY BLOCK -----"
    return out

def DecodePublicKey(file):
    with open(file, "r") as f:
        firstline = f.readline()
        blankline = f.readline()
        name = f.readline().replace("Name:  ", "")
        name = name.replace("\n", "")
        blankline = f.readline()
        pubkey = ''
        for line in f:
            pubkey += line.replace("\n", "")
        f.close()
        pubkey = remove_last_line_from_string(pubkey)

    return pubkey

def ImportPublicKey(file):
    with open(file, "r") as f:
        firstline = f.readline()
        blankline = f.readline()
        name = f.readline().replace("Name:  ", "")
        name = name.replace("\n", "")
        blankline = f.readline()
        pubkey = ''
        for line in f:
            pubkey += line.replace("\n", "")
        f.close()
        pubkey = remove_last_line_from_string(pubkey)
        rem = len("               ----- END RF PUBKEY BLOCK -----")
        pubkey = pubkey[:-rem]

    public_fingerprint = GetFingerprint(pubkey)

    kr_block = {
        "pubkey" : pubkey,
        "name" : name,
        "public_fingerprint" : public_fingerprint
    }

    kr_json = json.dumps(kr_block)

    with open("keys/importedkeyring.kr", "a+") as k:
        k.write(kr_json)
        k.close()

def DecodePrivateKey(file, password):
    with open(file, "r") as f:
        firstline = f.readline()
        blankline = f.readline()
        name = f.readline().replace("Name:  ", "")
        name.replace("\n", "")
        link = f.readline.repalce("Link:  ", "")
        link.replace("\n", "")
        privkey = ''
        for line in f:
            privkey += line.replace("\n", "")
        f.close()
        privkey = remove_last_line_from_string(privkey)
        rem = len("              ----- END ENCRYPTED RF PRIVKEY BLOCK ----")
        privkey = privkey[:-rem]

    mapped_privkey = list(map(int,privkey.strip().split()))

    privkey = rfc.DecryptMessageSymmetrical(mapped_privkey, password, modulus=33011033)
    return privkey

def ImportPrivateKey(file, password):
    with open(file, "r") as f:
        firstline = f.readline()
        blankline = f.readline()
        name = f.readline().replace("Name:  ", "")
        name.replace("\n", "")
        link = f.readline().replace("Link:  ", "")
        link.replace("\n", "")
        blankline = f.readline()
        privkey = ''
        for line in f:
            privkey += line.replace("\n", "")
        f.close()
        privkey = remove_last_line_from_string(privkey)
        rem = len("              ----- END ENCRYPTED RF PRIVKEY BLOCK ----")
        privkey = privkey[:-rem]

    mapped_privkey = list(map(int,privkey.strip().split()))

    privkey = rfc.DecryptMessageSymmetrical(mapped_privkey, password, modulus=33011033)

    private_fingerprint = GetFingerprint(privkey)

    kr_block = {
        "privkey" : privkey,
        "name" : name,
        "link" : link,
        "private_fingerprint" : private_fingerprint
    }

    krjson = json.dumps(kr_block)

    with open("keys/importedkeyring.kr", "a+") as f:
        f.write(krjson + "\n")
        f.close()

def GetFingerprint(key):
    fingerprint = '0x'
    fingerprint += rfh.rfh256(str(key)).upper()
    return fingerprint

def remove_last_line_from_string(s):
    return s[:s.rfind('\n')]