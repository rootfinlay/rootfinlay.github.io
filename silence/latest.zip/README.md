# Silence

## Modifying the setup files
```text

# silence

server {
       listen 127.0.0.1:8080 default_server;  <---  Only change this line if you changed your torrc port
       server_name silence;

       location / {
         include proxy_params;
         proxy_pass http://unix:/home/rootfinlay/silence/app/silence_backend/silence.sock;  <---  CHANGE THIS LINE TO YOUR SILENCE PATH
         allow 127.0.0.1;
         deny all;
       }
     }

# silence.service

[Unit]
Description=silence service
Requires=silence.socket
After=network.target

[Service]
User=rootfinlay   <--  CHANGE THIS LINE TO YOUR USERNAME
Group=www-data
WorkingDirectory=/home/rootfinlay/silence/app/silence-backend/ <---  CHANGE THIS LINE TO YOUR SILENCE PATH
Environment="PATH=/home/rootfinlay/silence/app/virtualenvironment/bin" <---  CHANGE THIS LINE TO YOUR SILENCE PATH
ExecStart=/home/rootfinlay/silence/app/virtualenvironment/bin/gunicorn --access-logfile - --workers 3 --bind unix:/home/rootfinlay/silence/app/silence_backend/silence.sock wsgi:app <---  CHANGE THIS LINE TO YOUR SILENCE PATH

[Install]
WantedBy=multi-user.target

# silence.socket

[Unit]
Description=silence socket

[Socket]
ListenStream=/home/rootfinlay/silence/app/silence_backend/silence.sock <---  CHANGE THIS LINE TO YOUR SILENCE PATH

[Install]
WantedBy=sockets.target

# torrc 

Only change this if you know what you're doing.

```

## Installation & Running Silence
```console

# Clone the repo
$ git clone https://github.com/rfdevelopments/silence

# Run the install script
$ cd silence
$ chmod +x install.sh
$ ./install.sh

# Run Silence (regular mode)
$ python3 silence.py # Not implemented yet

# Run silence (daemon mode)
$ python3 silence.py daemon

```
