sudo apt-get update
sudo apt-get install tor python3 python3-pip