if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 
   exit 1
fi

wget https://finlaycampbell.xyz/silence/latest.zip
unzip latest.zip
systemctl stop silence.service
mv latest/assets/*.py ./app/silence-backend
systemctl start silence.service
rm -rf latest 
rm latest.zip
printf "[ SILENCE ]: Updated"